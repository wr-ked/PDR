
"use strict";

let miMensaje = require('./miMensaje.js');

module.exports = {
  miMensaje: miMensaje,
};
