
"use strict";

let miMensajeEjercicio = require('./miMensajeEjercicio.js');

module.exports = {
  miMensajeEjercicio: miMensajeEjercicio,
};
